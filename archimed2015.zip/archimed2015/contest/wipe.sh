echo [INFO]: Wiping problem 'physics'.
cd problems/physics
./wipe.sh
cd -

echo [INFO]: Wiping problem 'company'.
cd problems/company
./wipe.sh
cd -

echo [INFO]: Wiping problem 'roscomnadzor'.
cd problems/roscomnadzor
./wipe.sh
cd -

echo [INFO]: Wiping problem 'manhattan'.
cd problems/manhattan
./wipe.sh
cd -

echo [INFO]: Wiping problem 'elephant'.
cd problems/elephant
./wipe.sh
cd -

echo [INFO]: Wiping problem 'tomandjerry'.
cd problems/tomandjerry
./wipe.sh
cd -

echo [INFO]: Wiping problem 'coats'.
cd problems/coats
./wipe.sh
cd -

echo [INFO]: Wiping problem 'dispatcher'.
cd problems/dispatcher
./wipe.sh
cd -

echo [INFO]: Wiping russian contest statement.
cd statements/russian
./wipe.sh
cd -


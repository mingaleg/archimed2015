from sys import argv
from random import seed, uniform

seed(argv[3])

MAX_TEMP = 55
MIN_TEMP = -89

N = int(argv[1])
D = float(argv[2])
X = uniform(MIN_TEMP, MAX_TEMP)
A = [uniform(MIN_TEMP, MAX_TEMP) for i in range(N)]

print X, D
print N
print " ".join(map(str, A))

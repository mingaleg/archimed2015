C = 299792458

v1, v2 = map(int, input().split())

print(min(v1+v2, C))

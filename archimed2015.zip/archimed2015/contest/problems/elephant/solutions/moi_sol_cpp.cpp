#include<iostream>
#include<string>

int main() {
    std::string n;
    std::cin >> n;
    std::cout << n << std::endl;
}

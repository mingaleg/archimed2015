n = int(raw_input())
a = sorted(map(int, raw_input().split()))
people_doing = 0
for x in a:
    if people_doing >= x:
        people_doing += 1
if people_doing == n:
    print 'YES'
else:
    print 'NO'


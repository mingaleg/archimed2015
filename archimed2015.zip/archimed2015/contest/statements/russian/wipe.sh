cd ../../problems/physics/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/company/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/roscomnadzor/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/manhattan/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/elephant/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/tomandjerry/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/coats/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/dispatcher/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
